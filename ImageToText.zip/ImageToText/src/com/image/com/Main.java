package com.image.com;
import java.io.PrintWriter;
public class Main {
public static void main(String[] args) {
 String input_file="C:\\bills\\bill1.jpg";
 String output_file="C:\\out";
 String tesseract_install_path="C:\\Program Files (x86)\\Tesseract-OCR\\tesseract";
 String[] command =
    {
        "cmd",
    };
    Process p;
 try {
 p = Runtime.getRuntime().exec(command);
        new Thread(new Logic(p.getErrorStream(), System.err)).start();
        new Thread(new Logic(p.getInputStream(), System.out)).start();
        PrintWriter stdin = new PrintWriter(p.getOutputStream());
        stdin.println("\""+tesseract_install_path+"\" \""+input_file+"\" \""+output_file+"\" -l eng");
        stdin.close();
        p.waitFor();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println(ReadFile.read_a_files(output_file+".txt"));
        System.out.println("swathi");
    } catch (Exception e) {
 e.printStackTrace();
    }
  }
}